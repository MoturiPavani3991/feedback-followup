var restify = require('restify');
var builder = require('botbuilder');
var LUIS = require('luis-sdk');
var moment = require('moment');
var ping = require("ping");
var unirest = require("unirest");
// const request = require('request-promise')
var request = require('request');
var globalOrder = null;
var bot = new builder.UniversalBot(connector);
var server = restify.createServer();
// var server = restify.createServer();
var session1;
server.listen(process.env.port || process.env.PORT || 8000, function () {
    console.log("--------------------------------------------------------");
    console.log("L&D Smart Assistant is running with the address : " + server.url);
    console.log("--------------------------------------------------------");
});
var connector = new builder.ChatConnector({
    appId: "d416189b-db2b-4a31-a716-c8de61d92f73",
    appPassword: "3z*JPC5bI@dh1IaUgR.]MIUX3?InEUrI"
});
var bot = new builder.UniversalBot(connector, {
    storage: new builder.MemoryBotStorage()
});
server.get('/followup', (req, res) => {

    var address =
    {
        channelId: 'msteams',
        user: { id: '29:1MRCQcVpFOUGrJ7yN6PQRoezTctxRlArksnXD9v6C0gOE3C8MrpY00MINKtqhPFjds6sDCk14igf2I7q-awZPRA' },
        channelData: {
            tenant: {
                id: '08c14ce7-cb84-43e8-b04a-50a5afe9bdf9'
            }
        },
        bot:
        {
            id: 'd416189b-db2b-4a31-a716-c8de61d92f73',
            name: '3z*JPC5bI@dh1IaUgR.]MIUX3?InEUrI'
        },
        serviceUrl: 'https://smba.trafficmanager.net/amer/',
        useAuth: true
    }

    var msg = new builder.Message().address(address);
    msg.text('I see that you attended the session topic IOT & Implementation on Aug 30 2019 To ensure that you complete your course certification, you must take the assessment test');
    msg.addAttachment(
        new builder.HeroCard(session1)
            .text("Would you like for me to help schedule this?")
            .buttons([
                builder.CardAction.imBack(session1, "Yes I'm intrested", "Yes"),
                builder.CardAction.imBack(session1, "noRegistration", "No")
            ]))
    bot.send(msg);
    res.send("success");
})
server.get('/feedback', (req, res) => {

    var address =
    {
        channelId: 'msteams',
        user: { id: '29:1MRCQcVpFOUGrJ7yN6PQRoezTctxRlArksnXD9v6C0gOE3C8MrpY00MINKtqhPFjds6sDCk14igf2I7q-awZPRA' },
        channelData: {
            tenant: {
                id: '08c14ce7-cb84-43e8-b04a-50a5afe9bdf9'
            }
        },
        bot:
        {
            id: 'd416189b-db2b-4a31-a716-c8de61d92f73',
            name: '3z*JPC5bI@dh1IaUgR.]MIUX3?InEUrI'
        },
        serviceUrl: 'https://smba.trafficmanager.net/amer/',
        useAuth: true
    }

    var msg = new builder.Message().address(address);
    msg.text('I see that you attended the session topic IOT & Implementation on Aug 30 2019. Would you like to provide feedback on the session?');
    msg.addAttachment(
        new builder.HeroCard(session1)
            .buttons([
                builder.CardAction.imBack(session1, "Yes", "Yes"),
                builder.CardAction.imBack(session1, "No", "No"),
                builder.CardAction.imBack(session1, "Later", "Later")
            ]))
    bot.send(msg);
    res.send("success");
})
server.post('/api/messages', connector.listen());
// server.use(restify.conditionalRequest());
//var bot = new builder.UniversalBot(connector);
var bot = new builder.UniversalBot(connector, {
    storage: new builder.MemoryBotStorage()
});
var onum, onumber;
var model = 'https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/1d8f0713-b358-4f0f-9c19-b2d3fdec6220?verbose=true&timezoneOffset=-360&subscription-key=c2d40a5393cd495d81e8f0271cee39af&q='
var recognizer = new builder.LuisRecognizer(model);
var dialog = new builder.IntentDialog({
    recognizers: [recognizer]
});
var count = 0;
var n = 0;

var cards;
var reply;
server.post('/api/messages', connector.listen());
bot.dialog('/', dialog);
function feedback1(session) {
    return [
        new builder.HeroCard(session)
            .buttons([
                builder.CardAction.imBack(session, "Yes", "Yes"),
                builder.CardAction.imBack(session, "No", "No"),
                builder.CardAction.imBack(session, "Partially", "Partially"),

            ]),
    ];
}
function feedback2(session) {
    return [
        new builder.HeroCard(session)
            .buttons([
                builder.CardAction.imBack(session, "Excellent", "Excellent"),
                builder.CardAction.imBack(session, "Good", "Good"),
                builder.CardAction.imBack(session, "Okay", "Okay"),
                builder.CardAction.imBack(session, "Bad", "Bad")
            ]),
    ];
}
function feedback3(session) {
    return [
        new builder.HeroCard(session)
            .buttons([
                builder.CardAction.imBack(session, "1", "1"),
                builder.CardAction.imBack(session, "2", "2"),
                builder.CardAction.imBack(session, "3", "3"),
                builder.CardAction.imBack(session, "4", "4"),
                builder.CardAction.imBack(session, "5", "5")
            ]),
    ];
}
function eventRegistration(session) {
    return [
        new builder.HeroCard(session)
            .buttons([
                builder.CardAction.imBack(session, "September 10th 2019", "September 1st 2019"),
                builder.CardAction.imBack(session, "October 2nd 2019", "October 2nd 2019"),
                builder.CardAction.imBack(session, "November 22nd 2019", "November 22nd 2019"),
            ]),
    ];
}
bot.on('conversationUpdate', function (message) {
    console.log("message",message);
    if (message.membersAdded) {

        message.membersAdded.forEach(function (identity) {
            //  //console.log("Message in initial message" ,message);
            if (identity.id == message.address.bot.id) {
                var reply = new builder.Message()
                    .address(message.address)
                    .text("Hi <Name>, I’m Rose! A virtual assistant from Miracle’s L&D center ");
                bot.send(reply);
            }
        });
    }
});
dialog.matches('greetings', [

    function (session, args) {
        session1 = session
        console.log("message", session.message);
        console.log("serviceUrl", session.message.address.serviceUrl);
        console.log("session.message.sourceEvent.tenant.id", session.message.sourceEvent.tenant.id)
        console.log("session.message.user.id", session.message.user.id)

        session.sendTyping();
        //   session.send("Hello ** You **");
        session.send("Hi <Name>, I’m Rose! A virtual assistant from Miracle’s L&D center ");
    }
]);
dialog.matches('Later', [

    function (session, args) {
        session1 = session
        session.sendTyping();
        session.send("Sure, I will reach back to you later!");
       setTimeout(() => {
        request('http://localhost:8000/feedback', function (error, response, body) {
            console.log('error:', error); // Print the error if one occurred
            console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
            console.log('body:', body); // Print the HTML for the Google homepage.
          });
         // session.send("Hello, Later Welcome");
       }, 60000);
       
    }
]);
dialog.matches('noRegistration', [

    function (session, args) {
        session1 = session
        console.log("message", session.message);
        console.log("serviceUrl", session.message.address.serviceUrl);
        console.log("session.message.sourceEvent.tenant.id", session.message.sourceEvent.tenant.id)
        console.log("session.message.user.id", session.message.user.id)

        session.sendTyping();
        //   session.send("Hello ** You **");
        session.send("Sure, I can understand – thanks for attending the session!.");
    }
]);
dialog.matches('No', [

    function (session, args) {
        session1 = session
        console.log("message", session.message);
        console.log("serviceUrl", session.message.address.serviceUrl);
        console.log("session.message.sourceEvent.tenant.id", session.message.sourceEvent.tenant.id)
        console.log("session.message.user.id", session.message.user.id)

        session.sendTyping();
        session.send("Sure, I can understand – thanks for attending the session!.");
    }
]);
dialog.matches('Yes', [
    function (session, args) {
        console.log("inside feedback------------------------------", session)
        builder.Prompts.text(session, "Did you feel that the content in the session was relevant to what you were promised during registration?");
        var cards = feedback1(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);
    },
    function (session, args) {
        console.log("args", args.response);
        builder.Prompts.text(session, "How engaging was the main speaker ?");
        var cards = feedback2(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);
    },
    function (session, args) {
        console.log("args", args.response);
        builder.Prompts.text(session, "How would you rate the overall course content ?");
        var cards = feedback3(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);
    },
    function (session, args) {

        session.send("Thank you for spending your time, we will constantly put our effort to improve your learning experiences");
        session.endDialog();
        session.endConversation();
    },
]);
dialog.matches('intrested', [

    function (session, args) {
      //  console.log("inside assessment------------------------------")
        session.sendTyping();
        builder.Prompts.text(session, "Okay, these are the dates that I currently have available");
        var cards = eventRegistration(session);
        var reply = new builder.Message(session)
            .attachmentLayout(builder.AttachmentLayout.carousel)
            .attachments(cards);
        session.send(reply);



    },

    function (session, args) {
        console.log("args", args.response);
        session.send("Thank you, I have confirmed your slot for the assessment on " + args.response + " You have been sent a calendar invite as well.");
 }
]);

dialog.matches('Training_Sessions',[

    function(session,args){
    console.log("inside training sessions")
    //session.send("Please find the upcoming events on campus")
    session.sendTyping();
    var cards = getCardsAttachments3(session);
    var reply = new builder.Message(session)
    .attachmentLayout(builder.AttachmentLayout.carousel)
    .attachments(cards);
    session.send(reply);
    }
    ])

    function getCardsAttachments3(session) {
        //console.log("Session ", session);
        return [
            new builder.HeroCard(session)
                 
                .title('Accelerating the Journey to AI')
                .subtitle('Date : 1/12/2019','Timings : 3:20 PM')
                .text('Location : USA'),
                new builder.HeroCard(session)
                .title('The Blueprint for smart Businesses ')
                .subtitle('Date : 4/12/2019','Timings : 5:20 PM')
                .text('Location : Australia'),
                new builder.HeroCard(session)
                .title('Prominence of WikiNet')
                .subtitle('Date : 6/12/2019','Timings : 12:20 AM')
                .text('Location : Denmark')
              
        ];
    
    }
    dialog.matches('eventRegistration',[
        function(session,args){
            builder.Prompts.text(session,"Please find the upcoming events on campus, feel free to register.")
            var cards = eventregister(session);
            var reply = new builder.Message(session)
                .attachmentLayout(builder.AttachmentLayout.carousel)
                .attachments(cards);
            session.send(reply);
        },
        function(session,args){
            session.send("You have been successfully registered to " + args.response + ". The confirmation details have been sent to your email. Thanks for the registration.")
        }
    ])
    
    
     
    // function DetectionCard1(session) {
    //     //  //console.log("Session ", session);
    //     return [
    //         new builder.HeroCard(session)
    //             .title(session.type)
    //             .subtitle(session.info)
    //     ];
    // }
    function eventregister(session) {
        //console.log("Session ", session);
        return [
            new builder.HeroCard(session)
                .title("Autonomous : Empower Engineering")
               .buttons([
                    // builder.CardAction.imBack(session, "Bar faucets", "Bar faucets"),
                    builder.CardAction.imBack(session, 'Autonomous : Empower Engineering', "Register")
                   ]),
                new builder.HeroCard(session)
                .title("End to End Data Science Workshop")
                .buttons([
                    builder.CardAction.imBack(session, 'End to End Data Science Workshop', "Register")
                ]),
                new builder.HeroCard(session)
                .title("Security Master Skills")
                .buttons([
                    builder.CardAction.imBack(session, 'Security Master Skills', "Register")
                ])
    
        ];
    }
    function coursesearch(session) {
        //console.log("Session ", session);
        return [
            new builder.HeroCard(session)
                .title("Sensor Fusion Engineer")
               .buttons([
                    // builder.CardAction.imBack(session, "Bar faucets", "Bar faucets"),
                    builder.CardAction.imBack(session, 'Sensor Fusion Engineer', "Enroll")
                   ]),
                new builder.HeroCard(session)
                .title("Self Driving Car Engineer")
                .buttons([
                    builder.CardAction.imBack(session, 'Self Driving Car Engineer', "Enroll")
                ]),
                new builder.HeroCard(session)
                .title("Robotics Software Engineer")
                .buttons([
                    builder.CardAction.imBack(session, 'Robotics Software Engineer', "Enroll")
                ]),
                new builder.HeroCard(session)
                .title("Cyber-Physical Systems Design & Analysis")
                .buttons([
                    builder.CardAction.imBack(session, 'Cyber-Physical Systems Design & Analysis', "Enroll")
                ])
    
        ];
    }
    
    // dialog.matches('',[
    //     function(session,args){
    //         console.log(args)
    //         session.send("You have been successfully registered to " + args.response + ". Please find confirmation details order email.Thanks for the registration.")
    //     }
    // ])
    
    dialog.matches('Course_Search',[
    
        function(session,args){
            builder.Prompts.text(session,"I see that you from engineering, which topic would you like to learn more about")
        },
        function(session,args){
            if(args.response=='Autonomous Cars')
            builder.Prompts.text(session,"Here are the courses currently available on-demand, you can enroll by cliking on them")
            var cards = coursesearch(session);
            var reply = new builder.Message(session)
                .attachmentLayout(builder.AttachmentLayout.carousel)
                .attachments(cards);
            session.send(reply);
    
        },
    
        function(session,args){
            session.send("You have successfully enrolled for " + args.response + " . Further details have been sent to your email. Please check")
        }
    ])

